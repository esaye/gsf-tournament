# Player Photos for GSF Prelims WorldCup 2025

## Photo Naming Convention
Player photos should be named using the player's name in lowercase, with spaces replaced by underscores, and saved as .jpg files.

## Current Players and Expected Photo Files:
- Conteh, Ousman → `conteh_ousman.jpg`
- Sock, Richard John → `sock_richard_john.jpg`  
- Suso, Kebba → `suso_kebba.jpg`
- Sambou, Amadou → `sambou_amadou.jpg`
- Jah, Omar Malleh → `jah_omar_malleh.jpg`
- Nyass, Ebrima → `nyass_ebrima.jpg`
- Coron, Jimmy → `coron_jimmy.jpg`
- Sowe, Momodou → `sowe_momodou.jpg`

## Photo Requirements:
- Format: JPG
- Recommended size: 150x150 pixels or similar square aspect ratio
- File size: Keep under 100KB for web performance
- Background: Plain or professional background preferred

## Default Photo:
If a player-specific photo is not available, the system will use `unknown_player.gif` as the default.

## Adding New Photos:
1. Save the photo with the correct naming convention in this directory
2. Ensure the filename matches exactly (case-sensitive)
3. Test the tournament display to confirm photos load correctly
